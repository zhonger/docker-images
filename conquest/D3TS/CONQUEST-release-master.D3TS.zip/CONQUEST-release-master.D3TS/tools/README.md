Utilities for working with CONQUEST are located here.

1. Basis generation code
