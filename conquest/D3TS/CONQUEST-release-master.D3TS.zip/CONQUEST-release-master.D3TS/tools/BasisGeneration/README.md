# BasisGeneration
Code to create basis sets and format pseudopotentials for Conquest
